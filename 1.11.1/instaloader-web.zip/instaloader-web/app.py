import os, re, secrets, tempfile, threading, random, time, zipfile
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

import instaloader as il
import requests
from urllib.parse import urlparse
from flask import Flask, Response, abort, jsonify, request, send_file, session
from werkzeug.security import check_password_hash

DATA = Path(os.environ.get("DATA_DIR", "/var/lib/instaloader-web"))
DL = Path(os.environ.get("DOWNLOAD_DIR", DATA / "downloads")).resolve()
SESS = DATA / "sessions"
DL.mkdir(parents=True, exist_ok=True)
SESS.mkdir(parents=True, exist_ok=True)
os.chmod(SESS, 0o700)
HERE = Path(__file__).parent
PW_HASH = os.environ["WEBUI_PASSWORD_HASH"]

app = Flask(__name__)
app.secret_key = os.environ.get("WEBUI_SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Strict",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=16 * 1024,
)

USER_RE = re.compile(r"[A-Za-z0-9._]{1,30}")
URL_USER = re.compile(r"(?:https?://)?(?:www\.)?instagram\.com/([A-Za-z0-9._]{1,30})/?(?:[?#].*)?")
URL_POST = re.compile(r"(?:https?://)?(?:www\.)?instagram\.com/(?:[A-Za-z0-9._]{1,30}/)?(?:p|reels?|tv)/([A-Za-z0-9_-]{5,20})/?(?:[?#].*)?")

JOB = {"running": False, "kind": "", "log": [], "items": [], "states": {}, "files": {}, "done": 0, "total": 0}
STOP, LOCK = threading.Event(), threading.Lock()
PENDING = {}  # username -> (loader awaiting 2FA, timestamp)
FAILS = {"n": 0, "until": 0.0}


class Stopped(Exception):
    pass


# ---------- helpers ----------
def s(d, k):
    v = d.get(k)
    return v.strip() if isinstance(v, str) else ""


def sp(u):
    return SESS / f"session-{u}"


def sessions():
    return sorted(p.name[8:] for p in SESS.glob("session-*") if USER_RE.fullmatch(p.name[8:]))


def parse_user(t):
    t = t.strip().lstrip("@")
    m = URL_USER.fullmatch(t)
    t = m.group(1) if m else t
    return t.lower() if USER_RE.fullmatch(t) else None


def dest(*parts):
    p = DL.joinpath(*parts).resolve()
    if not p.is_relative_to(DL):
        raise ValueError("Bad path")
    return str(p)


def log(m):
    if len(JOB["log"]) < 5000:
        JOB["log"].append(time.strftime("%H:%M:%S ") + m)


def wait(sec):
    if STOP.wait(sec):
        raise Stopped


def guarded(o, fn):
    for _ in range(3):
        try:
            return fn()
        except il.TooManyRequestsException:
            log(f"Rate limited. Waiting {o['crit']:g} min")
            wait(o["crit"] * 60)
    raise RuntimeError("Still rate limited, giving up")


def auth(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("ok"):
            return jsonify(error="auth"), 401
        return f(*a, **k)
    return w


# ---------- security ----------
@app.before_request
def only_json_posts():
    if request.method == "POST" and not request.is_json:
        return jsonify(error="JSON required"), 415


@app.after_request
def headers(r):
    r.headers.setdefault("Cache-Control", "no-store")
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["X-Frame-Options"] = "DENY"
    r.headers["Referrer-Policy"] = "no-referrer"
    return r


@app.get("/")
def index():
    n = secrets.token_urlsafe(16)
    r = Response((HERE / "index.html").read_text().replace("__NONCE__", n), mimetype="text/html")
    r.headers["Content-Security-Policy"] = (
        f"default-src 'none'; script-src 'nonce-{n}'; style-src 'nonce-{n}'; "
        "connect-src 'self'; img-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
    )
    return r


@app.post("/api/auth")
def api_auth():
    if time.time() < FAILS["until"]:
        return jsonify(error="Too many attempts. Try again in a few minutes."), 429
    pw = (request.get_json(silent=True) or {}).get("password")
    if isinstance(pw, str) and check_password_hash(PW_HASH, pw):
        session.clear()
        session.permanent = True
        session["ok"] = True
        FAILS["n"] = 0
        return jsonify(ok=True)
    FAILS["n"] += 1
    if FAILS["n"] >= 5:
        FAILS.update(n=0, until=time.time() + 300)
    return jsonify(error="Wrong password"), 401


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True)


# ---------- instagram session ----------
@app.post("/api/ig/login")
@auth
def ig_login():
    d = request.get_json(silent=True) or {}
    u, code = s(d, "username").lower(), s(d, "code")
    pw = d.get("password") if isinstance(d.get("password"), str) else ""
    if not USER_RE.fullmatch(u):
        return jsonify(error="Invalid username"), 400
    now = time.time()
    for k in [k for k, v in PENDING.items() if now - v[1] > 300]:
        del PENDING[k]
    L = None
    try:
        if code and u in PENDING:
            L = PENDING.pop(u)[0]
            L.two_factor_login(code)
        elif pw:
            L = il.Instaloader(quiet=True)
            L.login(u, pw)
        elif sp(u).exists():
            L = il.Instaloader(quiet=True)
            L.load_session_from_file(u, str(sp(u)))
            if L.test_login() != u:
                return jsonify(error="Session expired. Log in with your password."), 400
            return jsonify(sessions=sessions())
        else:
            return jsonify(error="Password required"), 400
        L.save_session_to_file(str(sp(u)))
        os.chmod(sp(u), 0o600)
    except il.TwoFactorAuthRequiredException:
        PENDING[u] = (L, now)
        return jsonify(need_2fa=True)
    except il.BadCredentialsException:
        return jsonify(error="Bad credentials or 2FA code"), 400
    except il.InstaloaderException as e:
        return jsonify(error=f"Login failed: {e}"), 400
    return jsonify(sessions=sessions())


@app.post("/api/ig/forget")
@auth
def ig_forget():
    u = s(request.get_json(silent=True) or {}, "username").lower()
    if USER_RE.fullmatch(u):
        sp(u).unlink(missing_ok=True)
    return jsonify(sessions=sessions())


# ---------- scan & download jobs ----------
URL_STORY = re.compile(r"(?:https?://)?(?:www\.)?instagram\.com/stories/([A-Za-z0-9._]{1,30})/(\d{5,25})/?(?:[?#].*)?")
MAXI = 1000
SCAN = {"id": 0, "L": None, "objs": {}, "seen": set(), "thumbs": {}}
THUMB_HOSTS = (".cdninstagram.com", ".fbcdn.net")
LABEL = {"GraphImage": "Photo", "GraphVideo": "Video", "GraphSidecar": "Carousel",
         "GraphStoryImage": "Story photo", "GraphStoryVideo": "Story video"}


def num(d, k, lo, hi, x):
    try:
        v = float(d.get(k, x))
    except (TypeError, ValueError):
        return x
    return x if v != v else min(max(v, lo), hi)


def parse_line(t):
    m = URL_POST.fullmatch(t)
    if m:
        return ("post", m.group(1))
    m = URL_STORY.fullmatch(t)
    if m:
        if m.group(1).lower() == "highlights":
            raise ValueError("Highlight URLs are not supported. Fetch the profile and pick the highlight.")
        return ("story", int(m.group(2)))
    u = parse_user(t)
    if u:
        return ("user", u)
    raise ValueError(f"Not recognised: {t[:60]}")


def clean(d):
    user = s(d, "user").lower()
    if user and not (USER_RE.fullmatch(user) and sp(user).exists()):
        raise ValueError("Unknown session")
    lines = [x.strip() for x in s(d, "targets").splitlines() if x.strip()]
    if len(lines) > 20:
        raise ValueError("At most 20 lines")
    targets = [parse_line(x) for x in lines]
    saved = bool(d.get("saved"))
    if not targets and not saved:
        raise ValueError("Enter a username or URL")
    if (saved or any(t[0] == "story" for t in targets)) and not user:
        raise ValueError("Saved posts and story URLs need a logged-in session")

    def day(k, end=False):
        v = s(d, k)
        if not v:
            return None
        try:
            x = datetime.strptime(v, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Dates must be YYYY-MM-DD")
        return x + timedelta(days=1, seconds=-1) if end else x

    return dict(
        user=user, targets=targets, saved=saved,
        posts=bool(d.get("posts")), stories=bool(d.get("stories")),
        highlights=bool(d.get("highlights")), pic=bool(d.get("pic")),
        since=day("since"), until=day("until", True), max=int(num(d, "max", 1, 500, 30)),
        **timing(d),
    )


def timing(d):
    return dict(base=num(d, "base", 0, 60, 3), jitter=num(d, "jitter", 0, 60, 2), crit=num(d, "crit", 1, 180, 30))


def loader(o):
    L = il.Instaloader(
        quiet=True, download_video_thumbnails=False, download_geotags=False,
        download_comments=False, save_metadata=False, compress_json=False,
        post_metadata_txt_pattern="", max_connection_attempts=3,
    )
    if o["user"]:
        L.load_session_from_file(o["user"], str(sp(o["user"])))
        if L.test_login() != o["user"]:
            raise RuntimeError("Session expired. Log in again.")
        log(f"Using session: {o['user']}")
    else:
        log("Anonymous mode (public content only, tighter limits)")
    return L


def safe(u):
    return u if USER_RE.fullmatch(u or "") else "unknown"


def turl(o, attr="url"):
    try:
        return getattr(o, attr)
    except Exception:
        return None


def add(kind, obj, folder, owner, when, label, text, key, thumb=None):
    if key in SCAN["seen"]:
        return
    if len(JOB["items"]) >= MAXI:
        log(f"Item limit ({MAXI}) reached")
        raise Stopped
    SCAN["seen"].add(key)
    i = len(JOB["items"])
    SCAN["objs"][i] = (kind, obj, folder, owner)
    th = None
    if thumb:
        SCAN["thumbs"][i] = thumb
        th = f"/api/thumb/{SCAN['id']}/{i}"
    JOB["items"].append(dict(i=i, k=kind, u=owner, d=when, t=label, s=" ".join(text.split())[:100], th=th))


def add_post(p, saved=False):
    ow = safe(p.owner_username)
    add("post", p, dest("saved_posts", ow) if saved else dest(ow, "posts"), ow,
        f"{p.date_utc:%Y-%m-%d}", LABEL.get(p.typename, "Post"), f"{p.shortcode} {p.caption or ''}", ("p", p.shortcode), turl(p))


def add_story(it):
    ow = safe(it.owner_username)
    add("story", it, dest(ow, "stories"), ow, f"{it.date_utc:%Y-%m-%d %H:%M}",
        LABEL.get(it.typename, "Story"), str(it.mediaid), ("s", it.mediaid), turl(it))


def scan_posts(it, o, saved):
    older = n = 0
    for p in it:
        if STOP.is_set():
            raise Stopped
        d = p.date_utc
        if o["until"] and d > o["until"]:
            continue
        if o["since"] and d < o["since"]:
            older += 1
            if not saved and older >= 4:  # tolerate up to 3 pinned posts out of order
                break
            continue
        older = 0
        add_post(p, saved)
        n += 1
        if n >= o["max"]:
            break


def scan_stories(L, uid):
    for st in L.get_stories([uid]):
        for it in st.get_items():
            add_story(it)


def scan_hls(L, prof, u):
    for hl in L.get_highlights(prof):
        add("hl", hl, dest(u, "highlights"), u, "", f"Highlight ({hl.itemcount})", hl.title or "", ("h", hl.unique_id), turl(hl, "cover_url"))


def scan_run(o):
    L = loader(o)
    SCAN["L"] = L
    for t in o["targets"]:
        if STOP.is_set():
            raise Stopped
        if t[0] == "post":
            add_post(guarded(o, lambda: il.Post.from_shortcode(L.context, t[1])))
        elif t[0] == "story":
            add_story(guarded(o, lambda: il.StoryItem.from_mediaid(L.context, t[1])))
        else:
            u = t[1]
            prof = guarded(o, lambda: il.Profile.from_username(L.context, u))
            log(f"{u}: {prof.mediacount} posts")
            if o["pic"]:
                add("pic", prof, dest(u, "profile_pic"), u, "", "Profile picture", "", ("pic", u), turl(prof, "profile_pic_url"))
            if o["posts"]:
                guarded(o, lambda: scan_posts(prof.get_posts(), o, False))
            if o["stories"] or o["highlights"]:
                if not o["user"]:
                    log("Stories and highlights need a logged-in session. Skipped.")
                else:
                    if o["stories"]:
                        guarded(o, lambda: scan_stories(L, prof.userid))
                    if o["highlights"]:
                        guarded(o, lambda: scan_hls(L, prof, u))
    if o["saved"]:
        me = il.Profile.from_username(L.context, o["user"])
        guarded(o, lambda: scan_posts(me.get_saved_posts(), o, True))
    log(f"Found {len(JOB['items'])} items. Select and download.")


MEDIA = {".jpg", ".jpeg", ".png", ".webp", ".mp4"}


def stamp(d):
    return d.strftime("%Y-%m-%d_%H-%M-%S") + "_UTC"


def files_for(kind, obj, folder):
    base = Path(folder)
    if kind == "pic":
        found = sorted(base.glob("*profile_pic*"), key=lambda p: p.stat().st_mtime)[-1:]
    else:
        dates = [x.date_utc for x in obj.get_items()] if kind == "hl" else [obj.date_utc]
        found = [f for d in dates for f in sorted(base.glob(stamp(d) + "*"))]
    return [str(f) for f in found if f.suffix.lower() in MEDIA and f.is_file()]


def dl_run(o, ids):
    L = SCAN["L"]
    JOB.update(done=0, total=len(ids))
    for i in ids:
        if STOP.is_set():
            raise Stopped
        kind, obj, folder, owner = SCAN["objs"][i]
        L.dirname_pattern = folder

        def go():
            if kind == "post":
                return L.download_post(obj, target=owner)
            if kind == "story":
                return L.download_storyitem(obj, target=owner)
            if kind == "pic":
                L.download_profilepic(obj)
                return True
            return any([L.download_storyitem(x, target=owner) for x in obj.get_items()])

        try:
            new = guarded(o, go)
        except il.InstaloaderException as e:
            JOB["states"][i] = "err"
            log(f"#{i + 1} failed: {e}")
            continue
        JOB["states"][i] = "new" if new else "exists"
        JOB["done"] += 1
        try:
            JOB["files"][i] = files_for(kind, obj, folder)
        except Exception:
            JOB["files"][i] = []
        log(f"#{i + 1} {'saved' if new else 'already exists'}")
        if new:
            wait(o["base"] + random.uniform(0, o["jitter"]))
            if random.random() < 0.1:
                log("Short break")
                wait(random.uniform(10, 17))
    log("Finished")


def worker(fn, *args):
    try:
        fn(*args)
    except Stopped:
        log("Stopped")
    except Exception as e:
        log(f"Error: {type(e).__name__}: {e}")
    finally:
        JOB["running"] = False


@app.post("/api/scan")
@auth
def api_scan():
    try:
        o = clean(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify(error=str(e)), 400
    with LOCK:
        if JOB["running"]:
            return jsonify(error="A job is already running"), 409
        JOB.update(running=True, kind="scan", log=[], items=[], states={}, files={}, done=0, total=0)
        SCAN.update(id=SCAN["id"] + 1, L=None, objs={}, seen=set(), thumbs={})
        STOP.clear()
    threading.Thread(target=worker, args=(scan_run, o), daemon=True).start()
    return jsonify(ok=True)


@app.post("/api/download")
@auth
def api_download():
    d = request.get_json(silent=True) or {}
    ids = d.get("ids")
    with LOCK:
        if JOB["running"]:
            return jsonify(error="A job is already running"), 409
        if (not isinstance(ids, list) or not ids or len(ids) > MAXI
                or not all(type(i) is int and i in SCAN["objs"] for i in ids)):
            return jsonify(error="Select items first"), 400
        ids = list(dict.fromkeys(ids))
        JOB.update(running=True, kind="download", done=0, total=len(ids))
        STOP.clear()
    threading.Thread(target=worker, args=(dl_run, timing(d), ids), daemon=True).start()
    return jsonify(ok=True)


@app.post("/api/stop")
@auth
def stop():
    STOP.set()
    return jsonify(ok=True)


@app.get("/api/status")
@auth
def status():
    lg, it = JOB["log"], JOB["items"]
    n = request.args.get("since", 0, type=int)
    m = request.args.get("items", 0, type=int)
    n, m = (n if 0 <= n <= len(lg) else 0), (m if 0 <= m <= len(it) else 0)
    lc, ic = lg[n:], it[m:]
    return jsonify(running=JOB["running"], kind=JOB["kind"], done=JOB["done"], total=JOB["total"],
                   log=lc, next=n + len(lc), items=ic, inext=m + len(ic),
                   states=dict(JOB["states"]), sid=SCAN["id"], sessions=sessions())


@app.get("/api/thumb/<int:sid>/<int:i>")
@auth
def thumb(sid, i):
    # The browser only sends ids; the URL comes from our own scan data and must be an https Instagram CDN host.
    u = SCAN["thumbs"].get(i) if sid == SCAN["id"] else None
    p = urlparse(u or "")
    if p.scheme != "https" or not (p.hostname or "").endswith(THUMB_HOSTS):
        abort(404)
    try:
        r = requests.get(u, timeout=10, stream=True, allow_redirects=False, headers={"User-Agent": "Mozilla/5.0"})
        ct = r.headers.get("Content-Type", "").split(";")[0]
        if r.status_code != 200 or ct not in ("image/jpeg", "image/png", "image/webp"):
            abort(404)
        buf = b""
        for c in r.iter_content(65536):
            buf += c
            if len(buf) > 2_000_000:
                abort(404)
    except requests.RequestException:
        abort(404)
    return Response(buf, mimetype=ct, headers={"Cache-Control": "private, max-age=3600"})


@app.get("/api/save/<int:sid>")
@auth
def save(sid):
    # Serves only files this app recorded for downloaded items, and only from inside the downloads directory.
    if sid != SCAN["id"]:
        abort(404)
    try:
        ids = [int(x) for x in request.args.get("ids", "").split(",") if x][:MAXI]
    except ValueError:
        abort(400)
    files = []
    for i in dict.fromkeys(ids):
        for f in JOB["files"].get(i, []):
            p = Path(f).resolve()
            if p.is_relative_to(DL) and p.is_file():
                files.append(p)
    if not files:
        abort(404)
    if sum(p.stat().st_size for p in files) > 2_000_000_000:
        abort(413)
    if len(files) == 1:
        return send_file(files[0], as_attachment=True)
    tmp = tempfile.TemporaryFile()
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
        for p in files:
            z.write(p, p.relative_to(DL).as_posix())
    tmp.seek(0)
    return send_file(tmp, mimetype="application/zip", as_attachment=True, download_name="instaloader.zip")
