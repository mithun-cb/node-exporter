import os, re, secrets, threading, random, time
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

import instaloader as il
from flask import Flask, Response, jsonify, request, session
from werkzeug.security import check_password_hash

DATA = Path(os.environ.get("DATA_DIR", "/var/lib/instaloader-web"))
DL = Path(os.environ.get("DOWNLOAD_DIR", DATA / "downloads")).resolve()
SESS = DATA / "sessions"
DL.mkdir(parents=True, exist_ok=True)
SESS.mkdir(parents=True, exist_ok=True)
os.chmod(SESS, 0o700)
HERE = Path(__file__).parent
PW_HASH = os.environ["WEBUI_PASSWORD_HASH"]

app = Flask(__name__)
app.secret_key = os.environ.get("WEBUI_SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Strict",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "1") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=16 * 1024,
)

USER_RE = re.compile(r"[A-Za-z0-9._]{1,30}")
URL_USER = re.compile(r"(?:https?://)?(?:www\.)?instagram\.com/([A-Za-z0-9._]{1,30})/?(?:[?#].*)?")
URL_POST = re.compile(r"(?:https?://)?(?:www\.)?instagram\.com/(?:[A-Za-z0-9._]{1,30}/)?(?:p|reels?|tv)/([A-Za-z0-9_-]{5,20})/?(?:[?#].*)?")
CODE_RE = re.compile(r"[A-Za-z0-9_-]{5,20}")

JOB = {"running": False, "log": [], "done": 0, "total": 0}
STOP, LOCK = threading.Event(), threading.Lock()
PENDING = {}  # username -> (loader awaiting 2FA, timestamp)
FAILS = {"n": 0, "until": 0.0}


class Stopped(Exception):
    pass


# ---------- helpers ----------
def s(d, k):
    v = d.get(k)
    return v.strip() if isinstance(v, str) else ""


def sp(u):
    return SESS / f"session-{u}"


def sessions():
    return sorted(p.name[8:] for p in SESS.glob("session-*") if USER_RE.fullmatch(p.name[8:]))


def parse_user(t):
    t = t.strip().lstrip("@")
    m = URL_USER.fullmatch(t)
    t = m.group(1) if m else t
    return t.lower() if USER_RE.fullmatch(t) else None


def dest(*parts):
    p = DL.joinpath(*parts).resolve()
    if not p.is_relative_to(DL):
        raise ValueError("Bad path")
    return str(p)


def log(m):
    if len(JOB["log"]) < 5000:
        JOB["log"].append(time.strftime("%H:%M:%S ") + m)


def wait(sec):
    if STOP.wait(sec):
        raise Stopped


def guarded(o, fn):
    for _ in range(3):
        try:
            return fn()
        except il.TooManyRequestsException:
            log(f"Rate limited. Waiting {o['crit']:g} min")
            wait(o["crit"] * 60)
    raise RuntimeError("Still rate limited, giving up")


def auth(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("ok"):
            return jsonify(error="auth"), 401
        return f(*a, **k)
    return w


# ---------- security ----------
@app.before_request
def only_json_posts():
    if request.method == "POST" and not request.is_json:
        return jsonify(error="JSON required"), 415


@app.after_request
def headers(r):
    r.headers["Cache-Control"] = "no-store"
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["X-Frame-Options"] = "DENY"
    r.headers["Referrer-Policy"] = "no-referrer"
    return r


@app.get("/")
def index():
    n = secrets.token_urlsafe(16)
    r = Response((HERE / "index.html").read_text().replace("__NONCE__", n), mimetype="text/html")
    r.headers["Content-Security-Policy"] = (
        f"default-src 'none'; script-src 'nonce-{n}'; style-src 'nonce-{n}'; "
        "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
    )
    return r


@app.post("/api/auth")
def api_auth():
    if time.time() < FAILS["until"]:
        return jsonify(error="Too many attempts. Try again in a few minutes."), 429
    pw = (request.get_json(silent=True) or {}).get("password")
    if isinstance(pw, str) and check_password_hash(PW_HASH, pw):
        session.clear()
        session.permanent = True
        session["ok"] = True
        FAILS["n"] = 0
        return jsonify(ok=True)
    FAILS["n"] += 1
    if FAILS["n"] >= 5:
        FAILS.update(n=0, until=time.time() + 300)
    return jsonify(error="Wrong password"), 401


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True)


# ---------- instagram session ----------
@app.post("/api/ig/login")
@auth
def ig_login():
    d = request.get_json(silent=True) or {}
    u, code = s(d, "username").lower(), s(d, "code")
    pw = d.get("password") if isinstance(d.get("password"), str) else ""
    if not USER_RE.fullmatch(u):
        return jsonify(error="Invalid username"), 400
    now = time.time()
    for k in [k for k, v in PENDING.items() if now - v[1] > 300]:
        del PENDING[k]
    L = None
    try:
        if code and u in PENDING:
            L = PENDING.pop(u)[0]
            L.two_factor_login(code)
        elif pw:
            L = il.Instaloader(quiet=True)
            L.login(u, pw)
        elif sp(u).exists():
            L = il.Instaloader(quiet=True)
            L.load_session_from_file(u, str(sp(u)))
            if L.test_login() != u:
                return jsonify(error="Session expired. Log in with your password."), 400
            return jsonify(sessions=sessions())
        else:
            return jsonify(error="Password required"), 400
        L.save_session_to_file(str(sp(u)))
        os.chmod(sp(u), 0o600)
    except il.TwoFactorAuthRequiredException:
        PENDING[u] = (L, now)
        return jsonify(need_2fa=True)
    except il.BadCredentialsException:
        return jsonify(error="Bad credentials or 2FA code"), 400
    except il.InstaloaderException as e:
        return jsonify(error=f"Login failed: {e}"), 400
    return jsonify(sessions=sessions())


@app.post("/api/ig/forget")
@auth
def ig_forget():
    u = s(request.get_json(silent=True) or {}, "username").lower()
    if USER_RE.fullmatch(u):
        sp(u).unlink(missing_ok=True)
    return jsonify(sessions=sessions())


# ---------- download job ----------
def clean(d):
    mode = d.get("mode")
    if mode not in ("profile", "saved", "single"):
        raise ValueError("Bad mode")
    user = s(d, "user").lower()
    if user and not (USER_RE.fullmatch(user) and sp(user).exists()):
        raise ValueError("Unknown session")
    t = s(d, "target")
    if mode == "profile":
        t = parse_user(t)
        if not t:
            raise ValueError("Enter a valid username or profile URL")
    elif mode == "single":
        m = URL_POST.fullmatch(t) or CODE_RE.fullmatch(t)
        if not m:
            raise ValueError("Enter a valid post or reel URL")
        t = m.group(1) if m.groups() else m.group(0)
    elif not user:
        raise ValueError("Saved posts need a logged-in session")

    def num(k, lo, hi, x):
        try:
            v = float(d.get(k, x))
        except (TypeError, ValueError):
            return x
        return x if v != v else min(max(v, lo), hi)

    def day(k, end=False):
        v = s(d, k)
        if not v:
            return None
        try:
            x = datetime.strptime(v, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Dates must be YYYY-MM-DD")
        return x + timedelta(days=1, seconds=-1) if end else x

    return dict(
        mode=mode, target=t, user=user,
        posts=bool(d.get("posts")), stories=bool(d.get("stories")),
        highlights=bool(d.get("highlights")), pic=bool(d.get("pic")),
        since=day("since"), until=day("until", True),
        base=num("base", 0, 60, 3), jitter=num("jitter", 0, 60, 2), crit=num("crit", 1, 180, 30),
    )


def loader(o):
    L = il.Instaloader(
        quiet=True, download_video_thumbnails=False, download_geotags=False,
        download_comments=False, save_metadata=False, compress_json=False,
        post_metadata_txt_pattern="", max_connection_attempts=3,
    )
    if o["user"]:
        L.load_session_from_file(o["user"], str(sp(o["user"])))
        if L.test_login() != o["user"]:
            raise RuntimeError("Session expired. Log in again.")
        log(f"Using session: {o['user']}")
    else:
        log("Anonymous mode (public content only, tighter limits)")
    return L


def posts(L, it, o, folder, ordered):
    older = 0
    for p in it:
        if STOP.is_set():
            raise Stopped
        d = p.date_utc
        if o["until"] and d > o["until"]:
            continue
        if o["since"] and d < o["since"]:
            older += 1
            if ordered and older >= 4:  # tolerate up to 3 pinned posts out of order
                break
            continue
        older = 0
        L.dirname_pattern = folder(p)
        try:
            new = L.download_post(p, target=p.owner_username)
        except il.TooManyRequestsException:
            raise
        except il.InstaloaderException as e:
            log(f"Skipped {p.shortcode}: {e}")
            continue
        JOB["done"] += 1
        log(f"{'Saved' if new else 'Exists'} {p.shortcode} ({d:%Y-%m-%d})")
        if new:
            wait(o["base"] + random.uniform(0, o["jitter"]))
            if random.random() < 0.1:
                log("Short break")
                wait(random.uniform(10, 17))


def run(o):
    L = loader(o)
    t = o["target"]
    if o["mode"] == "single":
        p = il.Post.from_shortcode(L.context, t)
        JOB["total"] = 1
        L.dirname_pattern = dest(p.owner_username, "posts")
        guarded(o, lambda: L.download_post(p, target=p.owner_username))
        JOB["done"] = 1
        log(f"Saved {t}")
    elif o["mode"] == "saved":
        me = il.Profile.from_username(L.context, o["user"])
        folder = lambda p: dest("saved_posts", p.owner_username if USER_RE.fullmatch(p.owner_username) else "unknown")
        guarded(o, lambda: posts(L, me.get_saved_posts(), o, folder, False))
    else:
        prof = il.Profile.from_username(L.context, t)
        if o["pic"]:
            L.dirname_pattern = dest(t, "profile_pic")
            L.download_profilepic(prof)
            log("Profile picture done")
        if o["posts"]:
            JOB["total"] = 0 if (o["since"] or o["until"]) else prof.mediacount
            log(f"Posts: {prof.mediacount} on profile")
            folder = lambda p: dest(t, "posts")
            guarded(o, lambda: posts(L, prof.get_posts(), o, folder, True))
        if (o["stories"] or o["highlights"]) and not o["user"]:
            log("Stories and highlights need a logged-in session. Skipped.")
        else:
            if o["stories"]:
                L.dirname_pattern = dest(t, "stories")
                guarded(o, lambda: L.download_stories([prof.userid], filename_target=t))
                log("Stories done")
                wait((o["base"] + o["jitter"]) * 1.5)
            if o["highlights"]:
                L.dirname_pattern = dest(t, "highlights")
                guarded(o, lambda: L.download_highlights(prof, filename_target=t))
                log("Highlights done")
    log("Finished")


def worker(o):
    try:
        run(o)
    except Stopped:
        log("Stopped")
    except Exception as e:
        log(f"Error: {type(e).__name__}: {e}")
    finally:
        JOB["running"] = False


@app.post("/api/start")
@auth
def start():
    try:
        o = clean(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify(error=str(e)), 400
    with LOCK:
        if JOB["running"]:
            return jsonify(error="A job is already running"), 409
        JOB.update(running=True, log=[], done=0, total=0)
        STOP.clear()
    threading.Thread(target=worker, args=(o,), daemon=True).start()
    return jsonify(ok=True)


@app.post("/api/stop")
@auth
def stop():
    STOP.set()
    return jsonify(ok=True)


@app.get("/api/status")
@auth
def status():
    lg = JOB["log"]
    n = request.args.get("since", 0, type=int)
    n = n if 0 <= n <= len(lg) else 0
    chunk = lg[n:]
    return jsonify(running=JOB["running"], done=JOB["done"], total=JOB["total"],
                   log=chunk, next=n + len(chunk), sessions=sessions())
